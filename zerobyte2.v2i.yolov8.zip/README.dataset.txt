# zerobyte2 > 2024-11-09 7:08am
https://universe.roboflow.com/zerobyte/zerobyte2

Provided by a Roboflow user
License: CC BY 4.0

